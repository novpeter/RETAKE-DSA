/**
 * Created by Petr on 23.03.2017.
 */
public class MaxHeap {
    private int capacity; //maximum number of elements
    private int size = 0; //number of elements
    private Process[] heap;


    protected MaxHeap(int capacity) {
        this.capacity = capacity;
        heap = new Process[capacity];
    }

    protected boolean isEmpty() {
        return (size == 0);
    }

    private int parent(int pos) {
        return pos / 2;
    }

    private int leftChild(int pos) {
        return (2 * pos);
    }

    private int rightChild(int pos) {
        return (2 * pos) + 1;
    }

    private boolean isLeaf(int pos) {
        if (pos >= (size / 2) && pos <= size) {
            return true;
        }
        return false;
    }

    protected void insert(Process e) {
        heap[++size] = e;
        upHeap();
    }

    protected Process remove() {
        Process popped = heap[0];
        heap[0] = heap[--size];
        maxHeapify(0);
        return popped;
    }

    private void maxHeapify(int pos) {
        if (!isLeaf(pos)) {
            if (heap[pos].getPriority() < heap[leftChild(pos)].getPriority() || heap[pos].getPriority() < heap[rightChild(pos)].getPriority()) {
                if (heap[leftChild(pos)].getPriority() > heap[rightChild(pos)].getPriority()) {
                    swap(pos, leftChild(pos));
                    maxHeapify(leftChild(pos));
                } else {
                    swap(pos, rightChild(pos));
                    maxHeapify(rightChild(pos));
                }
            }
        }
    }

    private void upHeap() {
        for (int pos = (size / 2); pos >= 1; pos--) {
            maxHeapify(pos);
        }
    }

    private void swap(int pos, int child) {
        Process e = heap[pos];
        heap[pos] = heap[child];
        heap[child] = e;
    }

}
