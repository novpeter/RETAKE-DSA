import java.util.ArrayList;

/**
 * Created by Petr on 23.03.2017.
 */
public class Scheduler {
    private static MaxHeap heap;
    private static ArrayList<Process> executionOrder;
    private static Process executingProcess;
    private static int currentTime;
    private static boolean executed = false; //false = some process hasn't executed yet.

    protected static String getLastEvent(ArrayList<Process> list){
        executionOrder = list;
        runProcesses();
        return "";
    }

    private static void runProcesses(){
        System.out.println(executionOrder.remove(1).getName());
        heap.insert(executionOrder.remove(1));

        while (currentTime < 120000 && !executionOrder.isEmpty()){
            if(!executed){
                executingProcess = heap.remove();
                for (Process process: executionOrder){
                    if(process.getEventTime() <= currentTime){
                        heap.insert(process);
                    }
                }
                currentTime += executingProcess.getCPU_time();
                executed = true;
            }else if (executed){
                if (!heap.isEmpty()){
                    executingProcess = heap.remove();

                }else{
                    currentTime = executionOrder.get(0).getEventTime();
                }
            }
        }
    }
}
